set define '^'
set verify off
prompt ...wwv_flow_seed_translations
create or replace procedure wwv_flow_seed_translations wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
1c2 12c
Ae6apmbleMb8dknPHaWtHHDrZ/4wg43I157hf3RG7YOwhS5ECI9cjvzf4jfx8qpxepQ1RDWO
cVIPD5ONO56sHb5ZF+a80dj6aURtaVyxU9pu5VRIxBMwrWTQQzgQMU9KbPVEaA3jgnkYWp4Z
onQM3gO+oIRpV7c1Eo8OMrWTJfFOysfkCqKKUJIRVGQ/nHt+ewAIqMDgGK0tER0hXmTRGEMd
arr63AyuQAulGvq2RTeEwym3EsKqTtBJ8LOuZT5IkEKI3haVCoT0s/300rA2wifi+UUgd0X7
xnUndQ==

/
show errors
