set define '^' verify off
prompt ...nv
create or replace function nv wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
a7 c6
RxgX2hQktKUPcbYOhUQXL2dvXDgwg3nw2stqyi9EXscYYjXCCRoyDRv2rEYfoOSX7TWXbiSn
bmVenUIDvzNiyUD+W1aO8PDL43QdlZ1pHI9nTTI4jz9+FKk95DiMLzHd+iBVwoeslMW9ADE4
ZL/E3W6E/onBAGle3FzWXYegCTWvpwGtCz6txKsGSaVUIA/XGBbV

/
show errors
